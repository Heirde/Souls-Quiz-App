# Imports
import tkinter as tk
from tkinter import *
import winsound
from tkinter import messagebox
import json
import os
from datetime import datetime
import PIL
from PIL import Image, ImageTk
from pathlib import Path

BASEDIR = Path(__file__).resolve().parent
class State:
    def __init__(self):
        self.question = 0
        self.score = 0
        self.selected = None

results_container = None

# Window Setup
window = tk.Tk()
window.title("Souls Quiz App")
window.geometry("390x844")

# Quiz File Management Functions
def save_quiz(quiz_data):
    if not os.path.exists("quizzes"):
        os.makedirs("quizzes")
    
    filename = quiz_data["title"].replace(' ','_').lower()
    filepath = f"quizzes/{filename}.json"
    
    quiz_data['created_date'] = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    with open(filepath, 'w') as f:
        json.dump(quiz_data, f, indent=4)
    
    print(f"Quiz saved: {filepath}")
    
def load_all_quizzes():
    quizzes = []

    if not os.path.exists("quizzes"):
        return quizzes
    
    for filename in os.listdir("quizzes"):
        if filename.endswith(".json"):
            filepath = f"quizzes/{filename}"
            with open(filepath, 'r') as f:
                quiz = json.load(f)
                quizzes.append(quiz)
    
    return quizzes

def show_saved_quizzes():
    quiz_list_window = tk.Toplevel(window)
    quiz_list_window.title("My Quizzes")
    quiz_list_window.geometry("390x844")
    quiz_list_window.configure(bg="#0A0A0A")
    
    title = tk.Label(
        quiz_list_window,text="My Quizzes",font=("Georgia", 28, "bold"),fg="#C8A951",bg="#0A0A0A")
    
    title.pack(pady=(30, 20))
    
    quizzes = load_all_quizzes()
    
    if not quizzes:
        tk.Label(quiz_list_window,text="No quizzes created yet",font=("Georgia", 13),fg="#6B6B6B",bg="#0A0A0A").pack(pady=50)
    else:
        for quiz in quizzes:
            quiz_frame = tk.Frame(quiz_list_window, bg="#8B1A1A", padx=2, pady=2)
            quiz_frame.pack(padx=20, pady=8, fill="x")
            
            quiz_btn = tk.Button(
                quiz_frame,
                text=f"{quiz['title']}\n{quiz['game']} • {quiz['difficulty']} • {len(quiz['questions'])} questions",
                font=("Georgia", 12),fg="#D4C5A9",bg="#1A1410",
                activeforeground="#C8A951",activebackground="#2A1F1A",justify="left",
                anchor="w",bd=0,relief="flat",cursor="hand2"
            )
            quiz_btn.pack(fill="both", padx=5, pady=5)
    

def delete_quiz(quiz_title):
    filename = quiz_title.replace(' ','_').lower()
    filepath = f"quizzes/{filename}.json"
    
    if os.path.exists(filepath):
        os.remove(filepath)
        print(f"Quiz deleted: {filepath}")

# Navigation Functions
def go_current_quizzes():
    home_frame.pack_forget()
    current_quizzes_frame.pack(fill="both", expand=True)
    if sound_var.get() == 1:
        sound_path = BASEDIR / "546974__finix473__ui_click.wav"

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )

def go_completed_quizzes():
    global results_container
    home_frame.pack_forget()
    completed_quizzes_frame.pack(fill="both", expand=True)

    quiz_results = load_quiz_results()

    if results_container is not None:
        results_container.destroy()
    results_container = tk.Frame(completed_quizzes_frame, bg="#1A1612")
    results_container.pack(padx=20, pady=10, fill="x")

    if not quiz_results:
        tk.Label(results_container,text="No completed quizzes yet.",font=("Georgia", 13),fg="#D4D9E0",bg="#1A1612").pack(pady=20)
    else:
        quiz_results.sort(key=lambda x: x.get("date", ""), reverse=True)
        for result in quiz_results:
            result_border = tk.Frame(results_container, padx=2, pady=2, bg="#D4A574")
            result_border.pack(pady=8, fill="x")
            btn_text = (
                f"{result.get('quiz_title', 'Unknown')}\n"
                f"{result.get('quiz_game', 'Unknown')} • Score: {result.get('score', 0)}/"
                f"{result.get('total', 0)} ({result.get('percentage', 0):.0f}%) • {result.get('date', '')}"
            )
            tk.Button(result_border, text=btn_text,
                      font=("Georgia", 12), fg="#D4C5A9", bg="#1A1410",
                      anchor="w", justify="left", bd=0, relief="flat",
                      cursor="hand2").pack(fill="both", padx=3, pady=3)

    if sound_var.get() == 1:
        sound_path = BASEDIR / "546974__finix473__ui_click.wav"

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )
    
def go_browse_quiz():
    home_frame.pack_forget()
    browse_quiz_frame.pack(fill="both", expand=True)
    if sound_var.get() == 1:
        sound_path = BASEDIR / "546974__finix473__ui_click.wav"

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )
    
def go_settings():
    home_frame.pack_forget()
    settings_page_frame.pack(fill="both", expand=True)
    if sound_var.get() == 1:
        sound_path = BASEDIR / "546974__finix473__ui_click.wav"

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )

def go_home():
    try:
        settings_page_frame.pack_forget()
        current_quizzes_frame.pack_forget()
        completed_quizzes_frame.pack_forget()
        new_quiz_frame.pack_forget()
        browse_quiz_frame.pack_forget()
        home_frame.pack(fill="both", expand=True)
    except:
        rebuild_home()
    
    if sound_var.get() == 1:
        sound_path = BASEDIR / "546974__finix473__ui_click.wav"

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC
        )

def rebuild_home():
    global home_frame, settings_page_frame, current_quizzes_frame
    global completed_quizzes_frame, new_quiz_frame, browse_quiz_frame
    global results_container
    
    for widget in window.winfo_children():
        widget.destroy()
    
    home_frame = tk.Frame(window, bg="#0A0A0A")
    
    header_frame = tk.Frame(home_frame, bg="#0A0A0A")
    header_frame.pack(pady=(80, 5), fill="x")
    
    home_title = tk.Label(header_frame, text="SOULS QUIZ APP", 
            font=("Georgia", 20,"bold"), 
            bg="#0A0A0A", fg="#C8A951" )
    
    home_title.pack(side="left", padx=(20, 0))
    
    settings_button = tk.Button(header_frame,
        text="⚙",font=("Arial", 20),fg="#C8A951",bg="#0A0A0A",
        bd=0,relief="flat",cursor="hand2",command=go_settings)
    
    settings_button.pack(side="right", padx=(0, 20))
    
    border1 = tk.Frame(home_frame, bg="#8B1A1A", padx=2, pady=2)
    border1.pack(padx=20, pady=8, fill="x")
    border2 = tk.Frame(home_frame, bg="#8B1A1A", padx=2, pady=2)
    border2.pack(padx=20, pady=8, fill="x")
    bottom_frame = tk.Frame(home_frame, bg="#0A0A0A")
    bottom_frame.pack(padx=20, pady=8, fill="x")
    make_border = tk.Frame(bottom_frame, bg="#8B1A1A", padx=2, pady=2)
    make_border.pack(side="left", expand=True, fill="both", padx=(0, 5))
    browse_border = tk.Frame(bottom_frame, bg="#8B1A1A", padx=2, pady=2)
    browse_border.pack(side="left", expand=True, fill="both", padx=(5, 0))
    
    current_quizzes_button = tk.Button(border1, text="Current Quizzes Created", font=("Georgia", 13, "italic"), 
            fg="#D4C5A9", bg="#1A1410", width=340, height=8, 
            command=current_quizzes_page,relief="flat", cursor="hand2")
    
    current_quizzes_button.pack(fill="both")
    
    recent_quizzes_button = tk.Button(border2, text="View recently completed quizzes", 
            font=("Georgia", 13, "italic"), fg="#D4C5A9", bg="#1A1410", 
            width=340, height=8, command=go_completed_quizzes,relief="flat", cursor="hand2")
    
    recent_quizzes_button.pack(fill="both")
    
    new_quiz_button = tk.Button(make_border, text="Make new quiz", 
            font=("Georgia", 13, "italic"), fg="#D4C5A9", bg="#1A1410",
            height=8, bd=0, relief="flat", cursor="hand2", command=make_new_quiz_page)
    
    new_quiz_button.pack(fill="both")
    
    browse_btn = tk.Button(
        browse_border,
        text="Browse Quizzes",font=("Georgia", 13),fg="#D4C5A9",bg="#1A1410",
        activeforeground="#C8A951",activebackground="#2A1F1A",
        height=8,bd=0,relief="flat",cursor="hand2", command=go_browse_quiz)
    
    browse_btn.pack(fill="both")
    
    #CUrrent quizzes page
    current_quizzes_frame = tk.Frame(window, bg="#141414")

    header_frame6 = tk.Frame(current_quizzes_frame, bg="#0A0A0A")
    header_frame6.pack(pady=(80, 5), fill="x")

    current_back_button = tk.Button(header_frame6, text="GO BACK", command=go_home, 
    fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))

    current_back_button.pack(side="left", padx=(20, 0))

    currentquiz_title = tk.Label(header_frame6, text="CURRENT QUIZZES", 
            font=("Georgia", 18,"bold"), 
            bg="#0D0D12", fg="#A8B5C7")

    currentquiz_title.pack(pady=5)
    
    #Completed quizzes page
    completed_quizzes_frame = tk.Frame(window, bg="#1A1612")

    header_frame5 = tk.Frame(completed_quizzes_frame, bg="#1A1612")
    header_frame5.pack(pady=(80, 5), fill="x")

    completed_back_button = tk.Button(header_frame5, text="GO BACK", command=go_home, 
    fg="#E8D5B7", bg="#1A1612", font=("Georgia", 12, "bold"))

    completed_back_button.pack(side="left", padx=(20, 0))

    completedquiz_title = tk.Label(header_frame5, text="COMPLETE QUIZZES", 
            font=("Georgia", 18,"bold"), 
            bg="#1A1612", fg="#E8D5B7")

    completedquiz_title.pack(pady=5)
    
    checkbox_border4 = tk.Frame(
        completed_quizzes_frame,
        bg="#D4A574",padx=1,pady=1)
    checkbox_border4.pack(padx=1, pady=1)

    completed_quiz_information = tk.Label(checkbox_border4, text="This page displays all of the quizzes that you have "
                                                                "completed. It also displays the score percentage of that " 
                                                                "quiz.",font=("Georgia", 13),
                                                            bg="#0D0D12", fg="#D4D9E0", wraplength=340)
    completed_quiz_information.pack(pady=5, padx=5)

    ds2_image_path = os.path.join(BASEDIR, "darksouls2.png")
    ds2_image_original = Image.open(ds2_image_path)
    ds2_image_resized = ds2_image_original.resize((390, 844))
    ds2_image = ImageTk.PhotoImage(ds2_image_resized)

    ds2_label = tk.Label(completed_quizzes_frame, image=ds2_image, bg="#1A1612", borderwidth=0)

    ds2_label.image = ds2_image
    ds2_label.place(x=20, y=70)
    ds2_label.lower()

    results_container = tk.Frame(completed_quizzes_frame, bg="#1A1612")
    results_container.pack(padx=20, pady=10, fill="x")

    #Make new quiz page
    new_quiz_frame = tk.Frame(window, bg="#111318")

    header_frame4 = tk.Frame(new_quiz_frame, bg="#0A0A0A")
    header_frame4.pack(pady=(80, 5), fill="x")

    new_back_button = tk.Button(header_frame4, text="GO BACK", command=go_home, 
    fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))

    new_back_button.pack(side="left", padx=(20, 0))

    newquiz_title = tk.Label(header_frame4, text="NEW QUIZZES", 
            font=("Georgia", 18,"bold"), 
            bg="#0D0D12", fg="#A8B5C7")

    newquiz_title.pack(pady=5)

    make_quiz_button = tk.Button(new_quiz_frame, text="Make New Quiz", font=("Georgia", 13), fg="#D4D9E0",bg="#0D0D12", command=make_new_quiz_page)
    make_quiz_button.pack(pady=5)

    #Browse quizzes frame
    browse_quiz_frame = tk.Frame(window, bg="#12140F")
    header_frame3 = tk.Frame(browse_quiz_frame, bg="#0A0A0A")
    header_frame3.pack(pady=(80, 5), fill="x")

    browse_back_button = tk.Button(header_frame3, text="GO BACK", command=go_home, 
    fg="#FFD700", bg="#12140F", font=("Georgia", 12, "bold"))

    browse_back_button.pack(side="left", padx=(20, 0))

    browsequiz_title = tk.Label(header_frame3, text="BROWSE QUIZZES", 
            font=("Georgia", 18,"bold"), 
            bg="#12140F", fg="#FFD700")

    browsequiz_title.pack(pady=5)

    show_available_quizzes = tk.Button(browse_quiz_frame, text="SHOW AVAILABLE QUIZZES",fg="#FFD700", 
    bg="#12140F", font=("Georgia", 12, "bold"))

    show_available_quizzes.pack(pady=5)
    show_available_quizzes.config(command=show_saved_quizzes)

    checkbox_border3 = tk.Frame(
        browse_quiz_frame,
        bg="#FF8C00",padx=1,pady=1)
    checkbox_border3.pack(padx=1, pady=1)

    available_quiz_information = tk.Label(checkbox_border3, text="In this page you will have access to the 'show available quizzes' button "
                                                            "which when you click it, it will open a new window which has all of the current available "
                                                            "quizzes that have already been made which you can access. This window can be closed if need be.", 
                                                            justify="left", font=("Georgia", 13),
                                                            bg="#0D0D12", fg="#D4D9E0", wraplength=340)

    available_quiz_information.pack(pady=5, padx=5)

    elden_logo_path = os.path.join(BASEDIR, "eldenringlogo.png")
    elden_logo = tk.PhotoImage(file=str(elden_logo_path))

    logo_label = tk.Label(browse_quiz_frame,image=elden_logo,bg="#12140F",cursor="hand2")

    logo_label.image = elden_logo
    logo_label.pack(pady=(5, 20))

    
    #Settings page
    settings_page_frame = tk.Frame(window, bg="#0D0D12")
    header_frame2 = tk.Frame(settings_page_frame, bg="#0A0A0A")
    header_frame2.pack(pady=(80, 5), fill="x")
    settings_back_button = tk.Button(header_frame2, text="GO BACK", command=go_home, 
    fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))
    settings_back_button.pack(side="left", padx=(20, 0))
    settings_title = tk.Label(header_frame2, text="SETTINGS PAGE", 
            font=("Georgia", 20,"bold"), 
            bg="#0D0D12", fg="#A8B5C7")
    settings_title.pack(pady=5)
    
    checkbox_border = tk.Frame(
        settings_page_frame,
        bg="#A8B5C7",padx=1,pady=1)
    checkbox_border.pack(padx=20, pady=5, fill="x")
    sound_check = tk.Checkbutton(checkbox_border, text="enable sound",
                                variable=sound_var, font=("Georgia", 16),fg="#D4D9E0",
                                bg="#0D0D12",selectcolor="#1E1F2A")
    sound_check.pack(fill="x", padx=5, pady=5)
    notifications_check = tk.Checkbutton(checkbox_border, text="enable notifications",
                                variable=notifications_var, font=("Georgia", 16),fg="#D4D9E0",
                                bg="#0D0D12",selectcolor="#1E1F2A")
    notifications_check.pack(fill="x", padx=5, pady=5)
    lightmode_check = tk.Checkbutton(checkbox_border, text="enable lightmode",
                                 variable=lightmode_var, font=("Georgia", 16), fg="#D4D9E0",
                                 bg="#0D0D12",selectcolor="#1E1F2A")
    lightmode_check.pack(fill="x", padx=5, pady=5)
    
    result_label = tk.Label(settings_page_frame, font=("Georgia", 12),fg="#D4D9E0",bg="#0D0D12")
    result_label.pack(pady=20)
    save_button = tk.Button(settings_page_frame, text="SAVE SETTINGS", command=lambda: apply_settings(result_label), 
    font=("Georgia", 20),fg="#D4D9E0",bg="#0D0D12")
    save_button.pack(pady=20)
    
    home_frame.pack(fill="both", expand=True)
    
# Home Page Frame
home_frame = tk.Frame(window, bg="#0A0A0A")

header_frame = tk.Frame(home_frame, bg="#0A0A0A")
header_frame.pack(pady=(80, 5), fill="x")

home_title = tk.Label(header_frame, text="SOULS QUIZ APP", 
        font=("Georgia", 20,"bold"), 
        bg="#0A0A0A", fg="#C8A951" )

home_title.pack(side="left", padx=(20, 0))

settings_button = tk.Button(header_frame,
    text="⚙",font=("Arial", 20),fg="#C8A951",bg="#0A0A0A",
    bd=0,relief="flat",cursor="hand2",command=go_settings)

settings_button.pack(side="right", padx=(0, 20))

border1 = tk.Frame(home_frame, bg="#8B1A1A", padx=2, pady=2)
border1.pack(padx=20, pady=8, fill="x")
border2 = tk.Frame(home_frame, bg="#8B1A1A", padx=2, pady=2)
border2.pack(padx=20, pady=8, fill="x")
bottom_frame = tk.Frame(home_frame, bg="#0A0A0A")
bottom_frame.pack(padx=20, pady=8, fill="x")
make_border = tk.Frame(bottom_frame, bg="#8B1A1A", padx=2, pady=2)
make_border.pack(side="left", expand=True, fill="both", padx=(0, 5))
browse_border = tk.Frame(bottom_frame, bg="#8B1A1A", padx=2, pady=2)
browse_border.pack(side="left", expand=True, fill="both", padx=(5, 0))

# Current Quizzes Page Function
def current_quizzes_page():
    for widget in window.winfo_children():
        widget.destroy()
    
    window.configure(bg="#141414")
    
    title = tk.Label(window,text="My Quizzes",font=("Georgia", 28, "bold"),fg="#B8960C",bg="#141414")
    title.pack(pady=(30, 20))
    
    back_btn = tk.Button(window,text="← Back",
        font=("Georgia", 12),fg="#8C7B3E",bg="#141414",
        bd=0,relief="flat",cursor="hand2",command=go_home)
    back_btn.place(x=20, y=20)
    
    quizzes = load_all_quizzes()
    
    if not quizzes:
        tk.Label(
            window,
            text="No quizzes created yet",
            font=("Georgia", 13),
            fg="#4A4A4A",
            bg="#141414"
        ).pack(pady=50)
    else:
        for quiz in quizzes:
            quiz_border = tk.Frame(window, bg="#B8960C", padx=2, pady=2)
            quiz_border.pack(padx=20, pady=8, fill="x")
            
            quiz_btn = tk.Button(
                quiz_border,
                text=f"{quiz['title']}\n{quiz['game']} • {quiz['difficulty']} • {len(quiz['questions'])} questions",
                font=("Georgia", 12),fg="#C8B89A",
                bg="#141414",activeforeground="#B8960C",activebackground="#2A2A35",justify="left",
                anchor="w", bd=0,relief="flat", cursor="hand2",command=lambda q=quiz: take_quiz_page(q))
            quiz_btn.pack(fill="both", padx=5, pady=5)

# Take Quiz Page Function
def take_quiz_page(quiz):
    for widget in window.winfo_children():
        widget.destroy()
    window.configure(bg="#0A0A0A")
    
    state = State()
    
    def show_question():
        for widget in window.winfo_children():
            widget.destroy()
        
        if state.question >= len(quiz['questions']):
            show_results()
            return
        
        q = quiz['questions'][state.question]
        tk.Label(window, text=quiz['title'], font=("Georgia", 20, "bold"), fg="#C8A951", bg="#0A0A0A").pack(pady=(30, 10))
        tk.Label(window, text=f"Question {state.question + 1}/{len(quiz['questions'])}  Score: {state.score}/{state.question}", font=("Georgia", 12), fg="#6B6B6B", bg="#0A0A0A").pack(pady=5)
        tk.Label(window, text=q['question'], font=("Georgia", 16), fg="#D4C5A9", bg="#0A0A0A", wraplength=350).pack(pady=(30, 20))
        
        state.selected = None
        btns = []
        
        for i, opt in enumerate(q['options']):
            f = tk.Frame(window, bg="#8B1A1A", padx=2, pady=2)
            f.pack(padx=30, pady=8, fill="x")
            btn = tk.Button(f, text=f"{chr(65+i)}. {opt}", font=("Georgia", 13), fg="#D4C5A9", bg="#1A1410", anchor="w", bd=0, relief="flat", cursor="hand2", command=lambda idx=i: [setattr(state, 'selected', idx)] + [b.config(bg="#8B1A1A" if j==idx else "#1A1410", fg="#C8A951" if j==idx else "#D4C5A9") for j, b in enumerate(btns)])
            btn.pack(fill="both", padx=3, pady=3)
            btns.append(btn)
        
        def submit():
            if state.selected is None:
                return messagebox.showwarning("No Answer", "Please select an answer")
            if state.selected == q['correct']:
                state.score += 1
                messagebox.showinfo("Correct!", "That's right!")
            else:
                messagebox.showinfo("Incorrect", f"Wrong! Answer was: {q['options'][q['correct']]}")
            state.question += 1
            show_question()
        
        tk.Button(window, text="Submit Answer", font=("Georgia", 14, "bold"), fg="#D4C5A9", bg="#8B1A1A", bd=0, relief="flat", cursor="hand2", command=submit).pack(pady=(30, 10))
        tk.Button(window, text="← Quit", font=("Georgia", 12), fg="#6B6B6B", bg="#0A0A0A", bd=0, relief="flat", cursor="hand2", command=go_home).place(x=20, y=20)
    
    def show_results():
        for widget in window.winfo_children():
            widget.destroy()
        window.configure(bg="#0A0A0A")
        
        pct = (state.score / len(quiz['questions'])) * 100
        msg = "Perfect!" if pct == 100 else "Excellent!" if pct >= 80 else "Good job!" if pct >= 60 else "Not bad!" if pct >= 40 else "Git gud!"
        
        tk.Label(window, text="Quiz Complete!", font=("Georgia", 28, "bold"), fg="#C8A951", bg="#0A0A0A").pack(pady=(50, 20))
        tk.Label(window, text=quiz['title'], font=("Georgia", 16), fg="#D4C5A9", bg="#0A0A0A").pack(pady=10)
        tk.Label(window, text=f"{state.score}/{len(quiz['questions'])}", font=("Georgia", 48, "bold"), fg="#C8A951", bg="#0A0A0A").pack(pady=20)
        tk.Label(window, text=f"{pct:.1f}%", font=("Georgia", 24), fg="#D4C5A9", bg="#0A0A0A").pack(pady=10)
        tk.Label(window, text=msg, font=("Georgia", 16, "italic"), fg="#8C7B3E", bg="#0A0A0A").pack(pady=20)
        
        save_quiz_result(quiz, state.score, len(quiz['questions']))
        
        f = tk.Frame(window, bg="#0A0A0A")
        f.pack(pady=30)
        tk.Button(f, text="Try Again", font=("Georgia", 14), fg="#D4C5A9", bg="#8B1A1A", bd=0, relief="flat", cursor="hand2", command=lambda: take_quiz_page(quiz)).pack(side="left", padx=10)
        tk.Button(f, text="Home", font=("Georgia", 14), fg="#D4C5A9", bg="#2A1F1A", bd=0, relief="flat", cursor="hand2", command=go_home).pack(side="left", padx=10)
    
    show_question()

# Save Quiz Result Function
def save_quiz_result(quiz, score, total):
    if not os.path.exists("results"):
        os.makedirs("results")
    results_file = "results/quiz_results.json"
    results = json.load(open(results_file)) if os.path.exists(results_file) else []
    results.append({"quiz_title": quiz['title'], "quiz_game": quiz['game'], "score": score, "total": total, "percentage": (score/total)*100, "date": datetime.now().strftime("%Y-%m-%d %H:%M")})
    json.dump(results, open(results_file, 'w'), indent=4)

# Load Quiz Results Function
def load_quiz_results():
    results_file = "results/quiz_results.json"
    return json.load(open(results_file)) if os.path.exists(results_file) else []

# Make New Quiz Page Function
def make_new_quiz_page():
    for widget in window.winfo_children():
        widget.destroy()
    
    window.configure(bg="#0A0A0A")
    
    title = tk.Label(window,text="Create Quiz",font=("Georgia", 28, "bold"),fg="#C8A951",bg="#0A0A0A")
    title.pack(pady=(30, 20))
    
    tk.Label(window,text="Quiz Title:",font=("Georgia", 13),fg="#D4C5A9",bg="#0A0A0A").pack(pady=(10, 5))
    
    title_entry = tk.Entry(window,font=("Georgia", 13),fg="#D4C5A9",bg="#1A1410",insertbackground="#C8A951", bd=0,width=30)
    title_entry.pack(pady=5)
    
    tk.Label(window,text="Game:",font=("Georgia", 13),fg="#D4C5A9",bg="#0A0A0A").pack(pady=(10, 5))
    
    game_var = tk.StringVar(value="Bloodborne")
    games = ["Bloodborne", "Dark Souls 1", "Dark Souls 2", "Dark Souls 3", 
             "Demon's Souls", "Elden Ring"]
    
    game_frame = tk.Frame(window, bg="#0A0A0A")
    game_frame.pack(pady=5)
    
    for game in games:
        tk.Radiobutton(game_frame,text=game,variable=game_var,value=game,font=("Georgia", 11),fg="#D4C5A9",bg="#0A0A0A",
            selectcolor="#1A1410",activeforeground="#C8A951", activebackground="#0A0A0A",bd=0,cursor="hand2").pack(anchor="w")
    
    tk.Label(window,text="Difficulty:",font=("Georgia", 13),fg="#D4C5A9", bg="#0A0A0A").pack(pady=(10, 5))
    
    difficulty_var = tk.StringVar(value="Medium")
    diff_frame = tk.Frame(window, bg="#0A0A0A")
    diff_frame.pack(pady=5)
    
    for diff in ["Easy", "Medium", "Hard"]: tk.Radiobutton(diff_frame,text=diff,variable=difficulty_var,value=diff,font=("Georgia", 11),fg="#D4C5A9",bg="#0A0A0A",
            selectcolor="#1A1410",activeforeground="#C8A951",activebackground="#0A0A0A",bd=0,cursor="hand2").pack(side="left", padx=10)

    back_btn = tk.Button(window,text="← Back",font=("Georgia", 12),
        fg="#6B6B6B",bg="#0A0A0A",bd=0,relief="flat",cursor="hand2",command=go_home)
    back_btn.place(x=20, y=20)
    
    def go_to_questions():
        if not title_entry.get().strip():
            messagebox.showwarning("Missing Title", "Please enter a quiz title")
            return
        
        quiz_data = {
            'title': title_entry.get().strip(),
            'game': game_var.get(),
            'difficulty': difficulty_var.get(),
            'questions': []
        }
        add_questions_page(quiz_data)
    
    next_btn = tk.Button(window,text="Add Questions →",
        font=("Georgia", 14, "bold"),fg="#D4C5A9",bg="#8B1A1A",activeforeground="#C8A951",
        activebackground="#2A1F1A",bd=0,relief="flat",cursor="hand2",command=go_to_questions)
    next_btn.pack(pady=(30, 10))

# Add Questions Page Function
def add_questions_page(quiz_data):
    for widget in window.winfo_children():
        widget.destroy()
    
    window.configure(bg="#0A0A0A")
    
    canvas = tk.Canvas(window, bg="#0A0A0A", highlightthickness=0)
    scrollbar = tk.Scrollbar(window, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas, bg="#0A0A0A")
    
    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )
    
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)
    
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")
    
    title = tk.Label(scrollable_frame,text="Add Question",font=("Georgia", 24, "bold"),fg="#C8A951", bg="#0A0A0A")
    title.pack(pady=(20, 15))
    
    counter_label = tk.Label(scrollable_frame,text=f"Question {len(quiz_data['questions']) + 1}",font=("Georgia", 12),fg="#6B6B6B",bg="#0A0A0A")
    counter_label.pack(pady=5)
    
    tk.Label(scrollable_frame,text="Question:",font=("Georgia", 12),fg="#D4C5A9",bg="#0A0A0A").pack(pady=(10, 5), anchor="w", padx=30)
    
    question_entry = tk.Entry(scrollable_frame,font=("Georgia", 12),fg="#D4C5A9",bg="#1A1410",insertbackground="#C8A951",bd=0,width=35)
    question_entry.pack(pady=5)
    
    option_entries = []
    options_labels = ["A", "B", "C", "D"]
    
    for i, label in enumerate(options_labels):
        tk.Label(scrollable_frame,text=f"Option {label}:",font=("Georgia", 11),fg="#D4C5A9",bg="#0A0A0A").pack(pady=(8, 2), anchor="w", padx=30)
        
        entry = tk.Entry(scrollable_frame,font=("Georgia", 11),fg="#D4C5A9",bg="#1A1410",insertbackground="#C8A951",bd=0,width=35)
        entry.pack(pady=2)
        option_entries.append(entry)
    
    tk.Label(scrollable_frame,text="Correct Answer:",font=("Georgia", 12),fg="#D4C5A9",bg="#0A0A0A").pack(pady=(15, 5))
    
    correct_var = tk.IntVar(value=0)
    correct_frame = tk.Frame(scrollable_frame, bg="#0A0A0A")
    correct_frame.pack(pady=5)
    
    for i, label in enumerate(options_labels):
        tk.Radiobutton(correct_frame,text=label,variable=correct_var,value=i,font=("Georgia", 11),fg="#D4C5A9",
            bg="#0A0A0A",selectcolor="#1A1410",activeforeground="#C8A951",activebackground="#0A0A0A",bd=0,cursor="hand2").pack(side="left", padx=8)
    
    def validate_and_add():
        if not question_entry.get().strip():
            messagebox.showwarning("Missing Question", "Please enter a question")
            return False
        
        for i, entry in enumerate(option_entries):
            if not entry.get().strip():
                messagebox.showwarning("Missing Option", f"Please fill in option {chr(65+i)}")
                return False
        
        question_data = {
            "question": question_entry.get().strip(),
            "options": [entry.get().strip() for entry in option_entries],
            "correct": correct_var.get()
        }
        quiz_data['questions'].append(question_data)
        return True
    
    def add_another():
        if validate_and_add():
            messagebox.showinfo("Success", "Question added!")
            add_questions_page(quiz_data)
    
    def finish_quiz():
        if not validate_and_add():
            return
        
        final_quiz = {
            "title": quiz_data['title'],
            "game": quiz_data['game'],
            "difficulty": quiz_data['difficulty'],
            "questions": quiz_data['questions']
        }
        
        save_quiz(final_quiz)
        
        messagebox.showinfo("Success", f"Quiz '{final_quiz['title']}' saved!")
        go_home()
    
    btn_frame = tk.Frame(scrollable_frame, bg="#0A0A0A")
    btn_frame.pack(pady=(25, 10))
    
    add_another_btn = tk.Button(btn_frame,text="+ Add Another",font=("Georgia", 12),fg="#D4C5A9",bg="#2A1F1A",activeforeground="#C8A951",
        activebackground="#1A1410",bd=0,relief="flat",cursor="hand2",command=add_another)
    add_another_btn.pack(side="left", padx=5)
    
    save_btn = tk.Button(btn_frame,text="Save Quiz",font=("Georgia", 12, "bold"),fg="#D4C5A9",bg="#8B1A1A",
        activeforeground="#C8A951",activebackground="#2A1F1A",bd=0,relief="flat",cursor="hand2",command=finish_quiz)
    save_btn.pack(side="left", padx=5)
    
    back_btn = tk.Button(window,text="← Back",font=("Georgia", 12),
        fg="#6B6B6B",bg="#0A0A0A",bd=0,relief="flat",cursor="hand2",command=make_new_quiz_page)
    back_btn.place(x=20, y=20)

# Home Page Buttons
current_quizzes_button = tk.Button(border1, text="Current Quizzes Created", font=("Georgia", 13, "italic"), 
        fg="#D4C5A9", bg="#1A1410", width=340, height=8, 
        command=current_quizzes_page,relief="flat", cursor="hand2")

current_quizzes_button.pack(fill="both")

recent_quizzes_button = tk.Button(border2, text="View recently completed quizzes", 
        font=("Georgia", 13, "italic"), fg="#D4C5A9", bg="#1A1410", 
        width=340, height=8, command=go_completed_quizzes,relief="flat", cursor="hand2")

recent_quizzes_button.pack(fill="both")

new_quiz_button = tk.Button(make_border, text="Make new quiz", 
        font=("Georgia", 13, "italic"), fg="#D4C5A9", bg="#1A1410",
        height=8, bd=0, relief="flat", cursor="hand2", command=make_new_quiz_page)

new_quiz_button.pack(fill="both")

browse_btn = tk.Button(
    browse_border,
    text="Browse Quizzes",font=("Georgia", 13),fg="#D4C5A9",bg="#1A1410",
    activeforeground="#C8A951",activebackground="#2A1F1A",
    height=8,bd=0,relief="flat",cursor="hand2", command=go_browse_quiz)

browse_btn.pack(fill="both")

home_frame.pack(fill="both", expand=True)

# Current Quizzes Frame
current_quizzes_frame = tk.Frame(window, bg="#141414")

header_frame6 = tk.Frame(current_quizzes_frame, bg="#0A0A0A")
header_frame6.pack(pady=(80, 5), fill="x")

current_back_button = tk.Button(header_frame6, text="GO BACK", command=go_home, 
fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))

current_back_button.pack(side="left", padx=(20, 0))

currentquiz_title = tk.Label(header_frame6, text="CURRENT QUIZZES", 
        font=("Georgia", 18,"bold"), 
        bg="#0D0D12", fg="#A8B5C7")

currentquiz_title.pack(pady=5)

# Completed Quizzes Frame
completed_quizzes_frame = tk.Frame(window, bg="#1A1612")

header_frame5 = tk.Frame(completed_quizzes_frame, bg="#1A1612")
header_frame5.pack(pady=(80, 5), fill="x")

completed_back_button = tk.Button(header_frame5, text="GO BACK", command=go_home, 
fg="#E8D5B7", bg="#1A1612", font=("Georgia", 12, "bold"))

completed_back_button.pack(side="left", padx=(20, 0))

completedquiz_title = tk.Label(header_frame5, text="COMPLETE QUIZZES", 
        font=("Georgia", 18,"bold"), 
        bg="#1A1612", fg="#E8D5B7")

completedquiz_title.pack(pady=5)

checkbox_border4 = tk.Frame(
    completed_quizzes_frame,
    bg="#D4A574",padx=1,pady=1)
checkbox_border4.pack(padx=1, pady=1)

completed_quiz_information = tk.Label(checkbox_border4, text="This page displays all of the quizzes that you have "
                                                            "completed. It also displays the score percentage of that " 
                                                            "quiz.",font=("Georgia", 13),
                                                        bg="#0D0D12", fg="#D4D9E0", wraplength=340)
completed_quiz_information.pack(pady=5, padx=5)

ds2_image_path = os.path.join(BASEDIR, "darksouls2.png")
ds2_image_original = Image.open(ds2_image_path)
ds2_image_resized = ds2_image_original.resize((390, 844))
ds2_image = ImageTk.PhotoImage(ds2_image_resized)

ds2_label = tk.Label(completed_quizzes_frame, image=ds2_image, bg="#1A1612", borderwidth=0)

ds2_label.image = ds2_image
ds2_label.place(x=20, y=70)
ds2_label.lower()

# New Quiz Frame
new_quiz_frame = tk.Frame(window, bg="#111318")

header_frame4 = tk.Frame(new_quiz_frame, bg="#0A0A0A")
header_frame4.pack(pady=(80, 5), fill="x")

new_back_button = tk.Button(header_frame4, text="GO BACK", command=go_home, 
fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))

new_back_button.pack(side="left", padx=(20, 0))

newquiz_title = tk.Label(header_frame4, text="NEW QUIZZES", 
        font=("Georgia", 18,"bold"), 
        bg="#0D0D12", fg="#A8B5C7")

newquiz_title.pack(pady=5)

make_quiz_button = tk.Button(new_quiz_frame, text="Make New Quiz", font=("Georgia", 13), fg="#D4D9E0",bg="#0D0D12", command=make_new_quiz_page)
make_quiz_button.pack(pady=5)

# Browse Quiz Frame
browse_quiz_frame = tk.Frame(window, bg="#12140F")
header_frame3 = tk.Frame(browse_quiz_frame, bg="#0A0A0A")
header_frame3.pack(pady=(80, 5), fill="x")

browse_back_button = tk.Button(header_frame3, text="GO BACK", command=go_home, 
fg="#FFD700", bg="#12140F", font=("Georgia", 12, "bold"))

browse_back_button.pack(side="left", padx=(20, 0))

browsequiz_title = tk.Label(header_frame3, text="BROWSE QUIZZES", 
        font=("Georgia", 18,"bold"), 
        bg="#12140F", fg="#FFD700")

browsequiz_title.pack(pady=5)

show_available_quizzes = tk.Button(browse_quiz_frame, text="SHOW AVAILABLE QUIZZES",fg="#FFD700", 
bg="#12140F", font=("Georgia", 12, "bold"))

show_available_quizzes.pack(pady=5)
show_available_quizzes.config(command=show_saved_quizzes)

checkbox_border3 = tk.Frame(
    browse_quiz_frame,
    bg="#FF8C00",padx=1,pady=1)
checkbox_border3.pack(padx=1, pady=1)

available_quiz_information = tk.Label(checkbox_border3, text="In this page you will have access to the 'show available quizzes' button "
                                                        "which when you click it, it will open a new window which has all of the current available "
                                                        "quizzes that have already been made which you can access. This window can be closed if need be.", 
                                                        justify="left", font=("Georgia", 13),
                                                        bg="#0D0D12", fg="#D4D9E0", wraplength=340)

available_quiz_information.pack(pady=5, padx=5)

elden_logo_path = os.path.join(BASEDIR, "eldenringlogo.png")
elden_logo = tk.PhotoImage(file=str(elden_logo_path))

logo_label = tk.Label(browse_quiz_frame,image=elden_logo,bg="#12140F",cursor="hand2")

logo_label.image = elden_logo
logo_label.pack(pady=(5, 20))

# Settings Page Frame
settings_page_frame = tk.Frame(window, bg="#0D0D12")

header_frame2 = tk.Frame(settings_page_frame, bg="#0A0A0A")
header_frame2.pack(pady=(80, 5), fill="x")

settings_back_button = tk.Button(header_frame2, text="GO BACK", command=go_home, 
fg="#D4D9E0", bg="#0D0D12", font=("Georgia", 12, "bold"))

settings_back_button.pack(side="left", padx=(20, 0))

settings_title = tk.Label(header_frame2, text="SETTINGS PAGE", 
        font=("Georgia", 20,"bold"), 
        bg="#0D0D12", fg="#A8B5C7")

settings_title.pack(pady=5)

sound_var = tk.IntVar()
notifications_var = tk.IntVar()
lightmode_var = tk.IntVar()

checkbox_border = tk.Frame(
    settings_page_frame,
    bg="#A8B5C7",padx=1,pady=1)

checkbox_border2 = tk.Frame(
    settings_page_frame,
    bg="#A8B5C7",padx=1,pady=1)

checkbox_border.pack(padx=20, pady=5, fill="x")
checkbox_border2.pack(padx=20, pady=5, fill="x")


sound_check = tk.Checkbutton(checkbox_border, text="enable sound",
                            variable=sound_var, font=("Georgia", 16),fg="#D4D9E0",
                            bg="#0D0D12",selectcolor="#1E1F2A")
sound_check.pack(fill="x", padx=5, pady=5)

notifications_check = tk.Checkbutton(checkbox_border, text="enable notifications",
                            variable=notifications_var, font=("Georgia", 16),fg="#D4D9E0",
                            bg="#0D0D12",selectcolor="#1E1F2A")
notifications_check.pack(fill="x", padx=5, pady=5)

lightmode_check = tk.Checkbutton(checkbox_border, text="enable lightmode",
                             variable=lightmode_var, font=("Georgia", 16), fg="#D4D9E0",
                             bg="#0D0D12",selectcolor="#1E1F2A")
lightmode_check.pack(fill="x", padx=5, pady=5)

settings_information = tk.Label(checkbox_border2, text="In this page you can make changes like light mode " 
                                                           "enabling notifications, and sounds. Tick the box and click save "
                                                           "settings to apply the settings you want. If you want to disable " 
                                                        "a setting, remove the tick from the box by clicking it again.", justify="left", font=("Georgia", 13, "bold"),
                                                        bg="#0D0D12", fg="#D4D9E0", wraplength=340)

settings_information.pack(padx=10, pady=20)

# Apply Settings Function
def apply_settings(result_label):
    settings = []
    if sound_var.get() == 1:
        settings.append("Sound ON")
        winsound.PlaySound(
            "546974__finix473__ui_click.wav", 
            winsound.SND_FILENAME | winsound.SND_ASYNC)
    if notifications_var.get() == 1:
        settings.append("Notifications ON")
        messagebox.showinfo("Success", "Settings saved successfully!")
    if lightmode_var.get() == 1:
        settings.append("Lightmode ON")
        try:
            settings_page_frame.config(bg="#F5F5F5")
            home_frame.config(bg="#F5F5F5")
            current_quizzes_frame.config(bg="#F5F5F5")
            completed_quizzes_frame.config(bg="#F5F5F5")
            new_quiz_frame.config(bg="#F5F5F5")
            browse_quiz_frame.config(bg="#F5F5F5")
            
        except:
            pass
    else:
        try:
            settings_page_frame.config(bg="#0D0D12")
            home_frame.config(bg="#0A0A0A")
            current_quizzes_frame.config(bg="#141414")
            completed_quizzes_frame.config(bg="#1A1612")
            new_quiz_frame.config(bg="#111318")
            browse_quiz_frame.config(bg="#12140F")
        except:
            pass

    result_label.config(text="Settings applied: "+", ".join(settings))

result_label = tk.Label(settings_page_frame, font=("Georgia", 12),fg="#D4D9E0",bg="#0D0D12")
result_label.pack(pady=20)
save_button = tk.Button(settings_page_frame, text="SAVE SETTINGS", command=lambda: apply_settings(result_label), 
font=("Georgia", 20),fg="#D4D9E0",bg="#0D0D12")
save_button.pack(pady=20)

# Start Application
window.mainloop()